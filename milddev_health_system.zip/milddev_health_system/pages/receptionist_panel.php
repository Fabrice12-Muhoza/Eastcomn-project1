<?php
require_once '../includes/auth.php';
require_roles(['receptionist']);
require_once '../config/db.php';
include '../includes/header.php';

$success = $error = '';

// Handle form submission for patient + appointment registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $appointment_date = $_POST['appointment_date'] ?? '';
    $appointment_reason = trim($_POST['appointment_reason'] ?? '');

    if ($full_name && $dob && $gender && $phone && $appointment_date) {
        // Insert patient
        $stmt_patient = $conn->prepare("INSERT INTO patients (full_name, date_of_birth, gender, phone) VALUES (?, ?, ?, ?)");
        $stmt_patient->bind_param("ssss", $full_name, $dob, $gender, $phone);
        if ($stmt_patient->execute()) {
            $patient_id = $stmt_patient->insert_id;

            // Insert appointment
            $stmt_appt = $conn->prepare("INSERT INTO appointments (patient_id, appointment_date, reason, status) VALUES (?, ?, ?, 'pending')");
            $stmt_appt->bind_param("iss", $patient_id, $appointment_date, $appointment_reason);
            if ($stmt_appt->execute()) {
                $success = "Patient registered and appointment scheduled!";
            } else {
                $error = "Failed to schedule appointment.";
            }
        } else {
            $error = "Failed to register patient.";
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<h1>Receptionist Control Panel</h1>

<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php elseif ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<h2>Register Patient & Schedule Appointment</h2>
<form method="POST" autocomplete="off">
    <fieldset>
        <legend>Patient Info</legend>
        <label>Full Name *</label>
        <input type="text" name="full_name" required>

        <label>Date of Birth *</label>
        <input type="date" name="dob" required>

        <label>Gender *</label>
        <select name="gender" required>
            <option value="">-- Select --</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>

        <label>Phone *</label>
        <input type="text" name="phone" required>
    </fieldset>

    <fieldset>
        <legend>Appointment Info</legend>
        <label>Appointment Date *</label>
        <input type="datetime-local" name="appointment_date" required>

        <label>Reason (optional)</label>
        <input type="text" name="appointment_reason">
    </fieldset>

    <button type="submit">Register & Schedule</button>
</form>

<h2>Quick Tools</h2>
<ul class="quick-links">
    <li><a href="../modules/patients/manage.php">Manage Patients</a></li>
    <li><a href="../appointments/manage.php">Manage Appointments</a></li>
    <li><a href="receptionist_dashboard.php">Go to Dashboard</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/receptionist_panel.php
?>
<?php
// End of file: milddev_heath_system/pages/receptionist_panel.php
?>
<li><a href="../appointments/calendar.php">View Calendar</a></li>
<?php
// End of file: milddev_heath_system/pages/receptionist_panel.php
?>
<?php
// End of file: milddev_heath_system/pages/receptionist_panel.php
?>
<?php
// End of file: milddev_heath_system/pages/receptionist_panel.php