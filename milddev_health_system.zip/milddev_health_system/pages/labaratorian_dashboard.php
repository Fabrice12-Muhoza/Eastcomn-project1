<?php
require_once '../includes/auth.php';
require_roles(['laboratorian']);
require_once '../config/db.php';
include '../includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

// Total lab tests assigned
$total_tests = $conn->query("SELECT COUNT(*) AS total FROM lab_tests WHERE laboratorian_id = $user_id")->fetch_assoc()['total'];

// Pending lab tests
$pending_tests = $conn->query("SELECT COUNT(*) AS total FROM lab_tests WHERE laboratorian_id = $user_id AND status = 'Pending'")->fetch_assoc()['total'];

// Completed lab tests
$completed_tests = $conn->query("SELECT COUNT(*) AS total FROM lab_tests WHERE laboratorian_id = $user_id AND status = 'Completed'")->fetch_assoc()['total'];

// Latest pending tests (limit 5)
$sql_pending = $conn->prepare("
    SELECT lt.id, p.full_name, lt.test_type, lt.scheduled_date, lt.status 
    FROM lab_tests lt 
    JOIN patients p ON lt.patient_id = p.id 
    WHERE lt.laboratorian_id = ? AND lt.status = 'Pending'
    ORDER BY lt.scheduled_date ASC 
    LIMIT 5
");
$sql_pending->bind_param("i", $user_id);
$sql_pending->execute();
$pending_list = $sql_pending->get_result();

?>

<h1>Laboratorian Dashboard</h1>

<div class="dashboard-stats">
    <div class="stat-card">
        <h3>Total Lab Tests</h3>
        <p><?= $total_tests ?></p>
    </div>
    <div class="stat-card warning">
        <h3>Pending Lab Tests</h3>
        <p><?= $pending_tests ?></p>
    </div>
    <div class="stat-card success">
        <h3>Completed Lab Tests</h3>
        <p><?= $completed_tests ?></p>
    </div>
</div>

<h2>Pending Lab Tests</h2>

<?php if ($pending_list->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Patient Name</th>
            <th>Test Type</th>
            <th>Scheduled Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($test = $pending_list->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($test['full_name']) ?></td>
            <td><?= htmlspecialchars($test['test_type']) ?></td>
            <td><?= htmlspecialchars($test['scheduled_date']) ?></td>
            <td><?= htmlspecialchars($test['status']) ?></td>
            <td>
                <a href="../modules/lab_tests/edit.php?id=<?= $test['id'] ?>" class="btn">✏️ Update</a>
                <a href="../modules/lab_tests/manage.php" class="btn">View All</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
    <p>No pending lab tests.</p>
<?php endif; ?>

<h2>Quick Links</h2>
<ul class="quick-links">
    <li><a href="../modules/lab_tests/manage.php">Manage Lab Tests</a></li>
    <li><a href="../modules/patients/manage.php">Manage Patients</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/labaratorian_dashboard.php
?> 