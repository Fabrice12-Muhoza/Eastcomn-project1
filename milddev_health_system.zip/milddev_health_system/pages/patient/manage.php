<?php
require_once '../../config/db.php';
require_once '../../config/auth.php';
checkAdmin();

$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);

    // Simple validation
    if (!$full_name || !$dob || !$gender) {
        $error = "Please fill all required fields.";
    } else {
        if (isset($_POST['id']) && $_POST['id']) {
            // Update existing patient
            $stmt = $conn->prepare("UPDATE patients SET full_name=?, dob=?, gender=?, phone=?, email=?, address=? WHERE id=?");
            $stmt->bind_param("ssssssi", $full_name, $dob, $gender, $phone, $email, $address, $_POST['id']);
            if ($stmt->execute()) {
                $message = "Patient updated successfully.";
            } else {
                $error = "Update failed.";
            }
        } else {
            // Insert new patient
            $stmt = $conn->prepare("INSERT INTO patients (full_name, dob, gender, phone, email, address) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $full_name, $dob, $gender, $phone, $email, $address);
            if ($stmt->execute()) {
                $message = "Patient added successfully.";
            } else {
                $error = "Insertion failed.";
            }
        }
    }
}

// Handle delete action
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM patients WHERE id=?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = "Patient deleted successfully.";
    } else {
        $error = "Delete failed.";
    }
}

// Fetch patients
$result = $conn->query("SELECT * FROM patients ORDER BY created_at DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Patients - Admin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 15px;}
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left;}
        th { background: #4CAF50; color: white; }
        form { margin-top: 20px; max-width: 600px;}
        input, select { padding: 8px; margin-bottom: 12px; width: 100%; box-sizing: border-box;}
        button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer;}
        .error { color: #e74c3c; margin-bottom: 15px; }
        .message { color: #2ecc71; margin-bottom: 15px; }
        .actions a { margin-right: 10px; color: #e74c3c; text-decoration: none; }
        .actions a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h1>Patient Management</h1>

<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<!-- Patient Form -->
<form method="POST" id="patient-form">
    <input type="hidden" name="id" id="patient_id" />
    <label>Full Name *</label>
    <input type="text" name="full_name" id="full_name" required />

    <label>Date of Birth *</label>
    <input type="date" name="dob" id="dob" required />

    <label>Gender *</label>
    <select name="gender" id="gender" required>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
    </select>

    <label>Phone</label>
    <input type="text" name="phone" id="phone" />

    <label>Email</label>
    <input type="email" name="email" id="email" />

    <label>Address</label>
    <input type="text" name="address" id="address" />

    <button type="submit">Save Patient</button>
</form>

<!-- Patients Table -->
<table>
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>DOB</th><th>Gender</th><th>Phone</th><th>Email</th><th>Address</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($patient = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $patient['id'] ?></td>
            <td><?= htmlspecialchars($patient['full_name']) ?></td>
            <td><?= htmlspecialchars($patient['dob']) ?></td>
            <td><?= htmlspecialchars($patient['gender']) ?></td>
            <td><?= htmlspecialchars($patient['phone']) ?></td>
            <td><?= htmlspecialchars($patient['email']) ?></td>
            <td><?= htmlspecialchars($patient['address']) ?></td>
            <td class="actions">
                <a href="#" onclick="editPatient(<?= htmlspecialchars(json_encode($patient)) ?>)">Edit</a>
                <a href="?delete=<?= $patient['id'] ?>" onclick="return confirm('Are you sure to delete this patient?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<script>
function editPatient(patient) {
    document.getElementById('patient_id').value = patient.id;
    document.getElementById('full_name').value = patient.full_name;
    document.getElementById('dob').value = patient.dob;
    document.getElementById('gender').value = patient.gender;
    document.getElementById('phone').value = patient.phone || '';
    document.getElementById('email').value = patient.email || '';
    document.getElementById('address').value = patient.address || '';
    window.scrollTo(0,0);
}
</script>

</body>
</html>
