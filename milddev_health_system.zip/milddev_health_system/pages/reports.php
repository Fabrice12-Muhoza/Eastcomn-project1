<?php
require_once 'includes/auth.php';
require_roles(['admin', 'receptionist']);
require_once 'config/db.php';
include 'includes/header.php';
?>

<h2>System Reports</h2>

<ul class="quick-links">
    <li><a href="report_pdf.php?type=appointments" target="_blank">📄 Appointments Report (PDF)</a></li>
    <li><a href="report_pdf.php?type=billing" target="_blank">💰 Billing Report (PDF)</a></li>
    <li><a href="report_pdf.php?type=pharmacy" target="_blank">💊 Pharmacy Stock Report (PDF)</a></li>
</ul>

<?php include 'includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/reports.php
?>
<?php
// End of file: milddev_heath_system/pages/reports.php  
$sql_upcoming = $conn->query("
SELECT a.*, p.full_name
FROM appointments a
JOIN patients p ON a.patient_id = p.id
WHERE a.appointment_date >= CURDATE()
ORDER BY a.appointment_date ASC, a.appointment_time ASC
LIMIT 5
");
