<?php
session_start();
require_once '../config/db.php';

$token = $_GET['token'] ?? '';
$error = '';
$success = '';

// Step 1: Validate token
if ($token) {
    $stmt = $conn->prepare("SELECT email, expires_at FROM password_resets WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($reset = $result->fetch_assoc()) {
        $email = $reset['email'];
        $expires = strtotime($reset['expires_at']);

        if (time() > $expires) {
            $error = "This link has expired. Please request a new one.";
        }
    } else {
        $error = "Invalid or expired token.";
    }
} else {
    $error = "No token provided.";
}

// Step 2: Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'], $_POST['confirm_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (strlen($newPassword) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        // ✅ UPDATE password in users table
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $newPassword, $email);
        $stmt->execute();

        // ✅ Delete used token
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $success = "Password reset successfully! You can now <a href='login.php'>login</a>.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Password - MHS</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    body {
        font-family: "Segoe UI", sans-serif;
        background: #e9f0f5;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    .reset-container {
        background: #fff;
        padding: 35px;
        border-radius: 10px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        width: 100%;
        max-width: 420px;
        text-align: center;
    }
    h2 {
        color: #009688;
    }
    input {
        width: 100%;
        padding: 12px;
        margin-top: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 15px;
    }
    button {
        width: 100%;
        padding: 12px;
        margin-top: 20px;
        background-color: #009688;
        color: white;
        border: none;
        font-size: 16px;
        border-radius: 6px;
        cursor: pointer;
    }
    button:hover {
        background-color: #00796b;
    }
    .error { color: #f44336; margin-top: 15px; }
    .success { color: #388e3c; margin-top: 15px; }
  </style>
</head>
<body>
<div class="reset-container">
    <h2>Reset Your Password</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php elseif ($token): ?>
        <form method="POST">
            <input type="password" name="new_password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Reset Password</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
