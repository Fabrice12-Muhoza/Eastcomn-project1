<?php
require_once '../includes/auth.php';
require_roles(['doctor']);
require_once '../config/db.php';
include '../includes/header.php';

$doctor_id = $_SESSION['user_id'] ?? 0;

// Total patients (unique patients doctor has appointments with)
$sql_patients = $conn->prepare("
    SELECT COUNT(DISTINCT patient_id) AS total 
    FROM appointments 
    WHERE doctor_id = ?
");
$sql_patients->bind_param("i", $doctor_id);
$sql_patients->execute();
$patient_count = $sql_patients->get_result()->fetch_assoc()['total'];

// Upcoming appointments (next 7 days)
$sql_appointments = $conn->prepare("
    SELECT a.id, p.full_name, a.appointment_date, a.status
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE a.doctor_id = ? AND a.appointment_date >= CURDATE()
    ORDER BY a.appointment_date ASC
    LIMIT 5
");
$sql_appointments->bind_param("i", $doctor_id);
$sql_appointments->execute();
$appointments = $sql_appointments->get_result();

// Pending lab results (assuming a 'lab_results' table)
$sql_pending_lab = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM lab_results 
    WHERE doctor_id = ? AND status = 'Pending'
");
$sql_pending_lab->bind_param("i", $doctor_id);
$sql_pending_lab->execute();
$pending_lab_count = $sql_pending_lab->get_result()->fetch_assoc()['total'];

?>

<h1>Doctor Dashboard</h1>

<div class="dashboard-stats">
    <div class="stat-card">
        <h3>My Patients</h3>
        <p><?= $patient_count ?></p>
    </div>
    <div class="stat-card">
        <h3>Upcoming Appointments</h3>
        <p><?= $appointments->num_rows ?></p>
    </div>
    <div class="stat-card warning">
        <h3>Pending Lab Results</h3>
        <p><?= $pending_lab_count ?></p>
    </div>
</div>

<h2>Upcoming Appointments</h2>

<?php if ($appointments->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Patient Name</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $appointments->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['appointment_date']) ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td>
                <a href="../modules/appointments/edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                <a href="../modules/appointments/manage.php" class="btn">View All</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
    <p>No upcoming appointments.</p>
<?php endif; ?>

<h2>Quick Links</h2>
<ul class="quick-links">
    <li><a href="../modules/patients/manage.php">My Patients</a></li>
    <li><a href="../modules/appointments/manage.php">Manage Appointments</a></li>
    <li><a href="../modules/billing/manage.php">Billing</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/doctor_dashboard.php
?>
<?php
// End of file: milddev_heath_system/pages/doctor_dashboard.php
<?php
$username = $_SESSION['user']['username'];
$sql_notif = $conn->prepare("SELECT * FROM notifications WHERE username = ? AND is_read = 0 ORDER BY created_at DESC");
$sql_notif->bind_param("s", $username);
$sql_notif->execute();
$result_notif = $sql_notif->get_result();
?>

<h3>Notifications</h3>
<?php if ($result_notif->num_rows > 0): ?>
    <ul>
        <?php while ($n = $result_notif->fetch_assoc()): ?>
            <li><?= htmlspecialchars($n['message']) ?> — <?= $n['created_at'] ?></li>
        <?php endwhile; ?>
    </ul>
<?php else: ?>
    <p>No new notifications.</p>
<?php endif; ?>
<?php
// End of file: milddev_heath_system/pages/doctor_dashboard.php
?>
<?php while ($n = $result_notif->fetch_assoc()): ?>
    <?php
        // Extract appointment ID from message (e.g., "appointment ID #23")
        preg_match('/#(\d+)/', $n['message'], $match);
        $appt_id = $match[1] ?? 0;
    ?>
    <li>
        <?= htmlspecialchars($n['message']) ?> — <?= $n['created_at'] ?>
        <?php if ($appt_id): ?>
            - <a href="../appointments/view_result.php?id=<?= $appt_id ?>">View Result</a>
        <?php endif; ?>
    </li>
<?php endwhile; ?>

