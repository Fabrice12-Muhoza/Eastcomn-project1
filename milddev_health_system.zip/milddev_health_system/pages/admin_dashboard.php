<?php
require_once '../includes/auth.php';
require_roles(['admin']);
require_once '../config/db.php';
include '../includes/header.php';

// Fetch stats
$patient_count = $conn->query("SELECT COUNT(*) AS total FROM patients")->fetch_assoc()['total'];
$appointment_count = $conn->query("SELECT COUNT(*) AS total FROM appointments")->fetch_assoc()['total'];
$billing_sum = $conn->query("SELECT IFNULL(SUM(amount),0) AS total FROM billing")->fetch_assoc()['total'];
$medicine_count = $conn->query("SELECT COUNT(*) AS total FROM pharmacy_stock")->fetch_assoc()['total'];
$pending_appointments = $conn->query("SELECT COUNT(*) AS total FROM appointments WHERE status = 'Pending'")->fetch_assoc()['total'];
$unpaid_bills = $conn->query("SELECT COUNT(*) AS total FROM billing WHERE status = 'Unpaid'")->fetch_assoc()['total'];
?>

<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9fafb;
    margin: 0;
    padding: 0 20px 40px;
    color: #333;
  }
  h1 {
    text-align: center;
    color: #2c3e50;
    margin-top: 40px;
    margin-bottom: 30px;
    font-weight: 700;
  }
  .dashboard-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 20px;
    max-width: 1000px;
    margin: 0 auto 50px;
  }
  .stat-card {
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0,0,0,0.1);
    padding: 30px 20px;
    text-align: center;
    transition: transform 0.2s ease-in-out;
  }
  .stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.15);
  }
  .stat-card h3 {
    margin: 0 0 12px;
    font-size: 1.2rem;
    color: #4CAF50;
    font-weight: 700;
  }
  .stat-card p {
    font-size: 2.6rem;
    font-weight: 900;
    margin: 0;
    color: #34495e;
  }
  .stat-card.warning h3 {
    color: #e74c3c;
  }
  .stat-card.warning p {
    color: #c0392b;
  }
  h2 {
    max-width: 1000px;
    margin: 0 auto 20px;
    color: #2c3e50;
    font-weight: 700;
  }
  .quick-links {
    max-width: 1000px;
    margin: 0 auto;
    list-style: none;
    padding: 0;
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
  }
  .quick-links li {
    flex: 1 1 200px;
  }
  .quick-links a {
    display: block;
    background-color: #4CAF50;
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    border-radius: 10px;
    font-weight: 700;
    text-align: center;
    transition: background-color 0.3s ease;
  }
  .quick-links a:hover {
    background-color: #388e3c;
  }
</style>

<h1>Admin Dashboard</h1>

<div class="dashboard-stats" role="region" aria-label="Key statistics">
    <div class="stat-card">
        <h3>Patients</h3>
        <p><?= $patient_count ?></p>
    </div>
    <div class="stat-card">
        <h3>Appointments</h3>
        <p><?= $appointment_count ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Billing ($)</h3>
        <p>$<?= number_format($billing_sum, 2) ?></p>
    </div>
    <div class="stat-card">
        <h3>Medicines in Pharmacy</h3>
        <p><?= $medicine_count ?></p>
    </div>
    <div class="stat-card warning" aria-live="polite">
        <h3>Pending Appointments</h3>
        <p><?= $pending_appointments ?></p>
    </div>
    <div class="stat-card warning" aria-live="polite">
        <h3>Unpaid Bills</h3>
        <p><?= $unpaid_bills ?></p>
    </div>
</div>

<h2>Quick Links</h2>
<ul class="quick-links" role="navigation" aria-label="Admin quick links">
    <li><a href="../modules/patients/manage.php">Manage Patients</a></li>
    <li><a href="../modules/appointments/manage.php">Manage Appointments</a></li>
    <li><a href="../modules/billing/manage.php">Manage Billing</a></li>
    <li><a href="../modules/pharmacy/manage.php">Manage Pharmacy Stock</a></li>
    <li><a href="../users/manage.php">Manage Users</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
