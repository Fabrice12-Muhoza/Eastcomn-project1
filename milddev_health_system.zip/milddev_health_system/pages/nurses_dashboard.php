<?php
require_once '../includes/auth.php';
require_roles(['nurse']);
require_once '../config/db.php';
include '../includes/header.php';

$nurse_id = $_SESSION['user_id'] ?? 0;

// Total patients assigned (assuming patients can be assigned to nurses)
$sql_patients = $conn->prepare("
    SELECT COUNT(DISTINCT p.id) AS total
    FROM patients p
    JOIN nurse_patient np ON np.patient_id = p.id
    WHERE np.nurse_id = ?
");
$sql_patients->bind_param("i", $nurse_id);
$sql_patients->execute();
$patient_count = $sql_patients->get_result()->fetch_assoc()['total'];

// Upcoming appointments nurse is assigned to (assuming nurse assigned appointments)
$sql_appointments = $conn->prepare("
    SELECT a.id, p.full_name, a.appointment_date, a.status
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN appointment_nurse an ON an.appointment_id = a.id
    WHERE an.nurse_id = ? AND a.appointment_date >= CURDATE()
    ORDER BY a.appointment_date ASC
    LIMIT 5
");
$sql_appointments->bind_param("i", $nurse_id);
$sql_appointments->execute();
$appointments = $sql_appointments->get_result();

?>

<h1>Nurse Dashboard</h1>

<div class="dashboard-stats">
    <div class="stat-card">
        <h3>My Patients</h3>
        <p><?= $patient_count ?></p>
    </div>
    <div class="stat-card">
        <h3>Upcoming Appointments</h3>
        <p><?= $appointments->num_rows ?></p>
    </div>
</div>

<h2>Upcoming Appointments</h2>

<?php if ($appointments->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Patient Name</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $appointments->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['appointment_date']) ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td>
                <a href="../modules/appointments/edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                <a href="../modules/appointments/manage.php" class="btn">View All</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
    <p>No upcoming appointments assigned to you.</p>
<?php endif; ?>

<h2>Quick Links</h2>
<ul class="quick-links">
    <li><a href="../modules/patients/manage.php">My Patients</a></li>
    <li><a href="../modules/appointments/manage.php">Manage Appointments</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/nurses_dashboard.php
?>