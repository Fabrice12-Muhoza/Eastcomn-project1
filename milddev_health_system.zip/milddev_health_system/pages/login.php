<?php
// Show all errors for debugging during development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php';

$login_error = '';
$signup_success = '';
$signup_error = '';

// LOGIN PROCESS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $login_error = 'Please enter both username and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, username, password, role, full_name FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            // Verify hashed password
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['full_name'] = $user['full_name'];

                // Redirect based on role
                switch ($user['role']) {
                    case 'admin':
                        header('Location: admin_dashboard.php');
                        break;
                    case 'doctor':
                        header('Location: doctor_dashboard.php');
                        break;
                    case 'pharmacist':
                        header('Location: pharmacist_dashboard.php');
                        break;
                    case 'laboratorian':
                        header('Location: laboratorian_dashboard.php');
                        break;
                    case 'receptionist':
                        header('Location: receptionist_dashboard.php');
                        break;
                    case 'nurse':
                        header('Location: nurses_dashboard.php');
                        break;
                    case 'xray':
                        header('Location: xray_dashboard.php');
                        break;
                    default:
                        header('Location: guest_dashboard.php');
                        break;
                }
                exit;
            } else {
                $login_error = 'Invalid username or password.';
            }
        } else {
            $login_error = 'Invalid username or password.';
        }
    }
}

// SIGN UP PROCESS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $new_username = trim($_POST['new_username']);
    $new_password = $_POST['new_password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role = $_POST['role'];

    if (!$new_username || !$new_password || !$full_name || !$role) {
        $signup_error = "Please fill all required fields.";
    } else {
        // Check if username already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $new_username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $signup_error = "Username already taken.";
        } else {
            // Hash the password before saving to DB
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, email, phone, role) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $new_username, $hashed_password, $full_name, $email, $phone, $role);
            if ($stmt->execute()) {
                $signup_success = "Registration successful! You can now log in.";
            } else {
                $signup_error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>MHS | Login & Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
        font-family: Arial, sans-serif;
        background: #f0f2f5;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .container {
        background: white;
        padding: 40px 30px;
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        width: 360px;
    }
    h2 {
        color: #4CAF50;
        text-align: center;
        margin-bottom: 25px;
    }
    form {
        display: flex;
        flex-direction: column;
    }
    input, select {
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 14px;
    }
    button {
        padding: 12px;
        background-color: #4CAF50;
        border: none;
        color: white;
        font-size: 16px;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    button:hover {
        background-color: #45a049;
    }
    .toggle-link {
        text-align: center;
        margin-top: 15px;
        color: #333;
        cursor: pointer;
        font-size: 14px;
        text-decoration: underline;
    }
    .error, .success {
        text-align: center;
        font-weight: 600;
        margin-bottom: 15px;
    }
    .error {
        color: #e74c3c;
    }
    .success {
        color: #2ecc71;
    }
    #signup-box {
        display: none;
    }
    .forgot-link {
        text-align: right;
        font-size: 13px;
        margin-bottom: 15px;
    }
    .forgot-link a {
        color: #777;
        text-decoration: none;
    }
    .forgot-link a:hover {
        text-decoration: underline;
    }
  </style>
  <script>
    function toggleSignUp() {
      const loginBox = document.getElementById('login-box');
      const signupBox = document.getElementById('signup-box');
      if (signupBox.style.display === 'none' || signupBox.style.display === '') {
        signupBox.style.display = 'block';
        loginBox.style.display = 'none';
      } else {
        signupBox.style.display = 'none';
        loginBox.style.display = 'block';
      }
    }
  </script>
</head>
<body>

<div class="container" id="login-box">
  <h2>Login to MHS</h2>
  <?php if ($login_error): ?>
    <div class="error"><?= htmlspecialchars($login_error) ?></div>
  <?php endif; ?>
  <form method="POST" action="">
    <input type="text" name="username" placeholder="Username" required autocomplete="username" autofocus />
    <input type="password" name="password" placeholder="Password" required autocomplete="current-password" />
    <div class="forgot-link"><a href="forgot_password.php">Forgot Password?</a></div>
    <button type="submit" name="login">Log In</button>
  </form>
  <div class="toggle-link" onclick="toggleSignUp()">I am new to this system, Sign Up</div>
</div>

<div class="container" id="signup-box">
  <h2>Sign Up</h2>
  <?php if ($signup_success): ?>
    <div class="success"><?= htmlspecialchars($signup_success) ?></div>
  <?php endif; ?>
  <?php if ($signup_error): ?>
    <div class="error"><?= htmlspecialchars($signup_error) ?></div>
  <?php endif; ?>
  <form method="POST" action="">
    <input type="text" name="new_username" placeholder="Username" required />
    <input type="password" name="new_password" placeholder="Password" required />
    <input type="text" name="full_name" placeholder="Full Name" required />
    <input type="email" name="email" placeholder="Email (optional)" />
    <input type="text" name="phone" placeholder="Phone (optional)" />
    <select name="role" required>
      <option value="">Select Role</option>
      <option value="admin">Admin</option>
      <option value="doctor">Doctor</option>
      <option value="nurse">Nurse</option>
      <option value="receptionist">Receptionist</option>
      <option value="xray">X-ray Staff</option>
      <option value="pharmacist">Pharmacist</option>
    </select>
    <button type="submit" name="signup">Register</button>
  </form>
  <div class="toggle-link" onclick="toggleSignUp()">Already have an account? Log In</div>
</div>

</body>
</html>
<?php
require_once '../config/db.php';

$username = 'Wolf';
$plain_password = 'M1@fb758';

$hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
$stmt->bind_param("ss", $hashed_password, $username);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Password updated and hashed!";
} else {
    echo "Update failed or user not found.";
}
?>