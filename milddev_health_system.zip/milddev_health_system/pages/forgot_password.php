<?php
session_start();
require_once '../config/db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        $error = "Email is required.";
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            // Generate token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);

            // Save reset token
            $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $email, $token, $expires);
            $stmt->execute();

            // Simulate email by displaying link
            $resetLink = "http://localhost/milddev_health_system/pages/reset_password.php?token=$token";
            $message = "Recovery link sent successfully!<br><a href='$resetLink'>$resetLink</a>";
        } else {
            $error = "No account found with that email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MHS - Forgot Password</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", sans-serif;
            background: #e9f0f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .forgot-container {
            background: #fff;
            padding: 40px 35px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 430px;
            text-align: center;
        }

        .forgot-container h2 {
            color: #009688;
            margin-bottom: 25px;
        }

        input[type="email"] {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #009688;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: 0.3s ease;
        }

        button:hover {
            background-color: #00796b;
        }

        .message {
            margin-top: 20px;
            color: #388e3c;
        }

        .error {
            margin-top: 20px;
            color: #f44336;
        }

        a.back-link {
            display: inline-block;
            margin-top: 25px;
            text-decoration: none;
            color: #555;
            font-size: 14px;
        }

        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="forgot-container">
    <h2>Forgot Password</h2>
    <p>Please enter your registered email address to receive a recovery link.</p>

    <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
    <?php elseif ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Enter your email" required>
        <button type="submit">Send Recovery Link</button>
    </form>

    <a href="login.php" class="back-link">← Back to Login</a>
</div>
</body>
</html>
