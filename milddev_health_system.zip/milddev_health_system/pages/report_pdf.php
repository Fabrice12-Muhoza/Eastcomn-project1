<?php
require_once 'includes/auth.php';
require_roles(['admin', 'receptionist']);
require_once 'config/db.php';
require_once 'fpdf/fpdf.php';

$type = $_GET['type'] ?? 'appointments';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

if ($type === 'appointments') {
    $pdf->Cell(0, 10, 'Appointments Report', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);

    $sql = $conn->query("
        SELECT a.id, p.full_name, a.appointment_date, a.status 
        FROM appointments a 
        JOIN patients p ON a.patient_id = p.id 
        ORDER BY a.appointment_date DESC
    ");

    while ($row = $sql->fetch_assoc()) {
        $pdf->Cell(0, 10, $row['full_name'] . ' - ' . $row['appointment_date'] . ' (' . ucfirst($row['status']) . ')', 0, 1);
    }

} elseif ($type === 'billing') {
    $pdf->Cell(0, 10, 'Billing Report', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);

    $sql = $conn->query("
        SELECT b.id, p.full_name, b.total_amount, b.status, b.created_at
        FROM billing b
        JOIN patients p ON b.patient_id = p.id
        ORDER BY b.created_at DESC
    ");

    while ($row = $sql->fetch_assoc()) {
        $pdf->Cell(0, 10, $row['full_name'] . ' - $' . $row['total_amount'] . ' (' . ucfirst($row['status']) . ')', 0, 1);
    }

} elseif ($type === 'pharmacy') {
    $pdf->Cell(0, 10, 'Pharmacy Stock Report', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);

    $sql = $conn->query("SELECT * FROM pharmacy_stock ORDER BY medicine_name ASC");

    while ($row = $sql->fetch_assoc()) {
        $pdf->Cell(0, 10, $row['medicine_name'] . ' - Qty: ' . $row['quantity'] . ' ($' . $row['price_per_unit'] . '/unit)', 0, 1);
    }
} else {
    $pdf->Cell(0, 10, 'Invalid Report Type', 0, 1, 'C');
}

$pdf->Output();
exit;
?>
