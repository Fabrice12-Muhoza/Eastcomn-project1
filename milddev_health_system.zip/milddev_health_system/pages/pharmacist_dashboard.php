<?php
require_once '../includes/auth.php';
require_roles(['pharmacist']);
require_once '../config/db.php';
include '../includes/header.php';

// Total medicines in stock
$sql_stock = $conn->query("SELECT COUNT(*) AS total_medicines, SUM(quantity) AS total_quantity FROM pharmacy_stock");
$stock_info = $sql_stock->fetch_assoc();

// Low stock medicines (threshold = 10 units)
$sql_low_stock = $conn->prepare("SELECT id, medicine_name, quantity FROM pharmacy_stock WHERE quantity <= 10 ORDER BY quantity ASC");
$sql_low_stock->execute();
$low_stock = $sql_low_stock->get_result();

// Pending prescriptions to dispense (assuming 'status' = 'pending' in billing or prescription table)
$sql_pending = $conn->prepare("
    SELECT b.id, p.full_name AS patient_name, b.total_amount, b.status, b.created_at 
    FROM billing b
    JOIN patients p ON b.patient_id = p.id
    WHERE b.status = 'pending'
    ORDER BY b.created_at DESC
    LIMIT 10
");
$sql_pending->execute();
$pending_prescriptions = $sql_pending->get_result();

?>

<h1>Pharmacist Dashboard</h1>

<div class="dashboard-stats">
    <div class="stat-card">
        <h3>Total Medicines</h3>
        <p><?= $stock_info['total_medicines'] ?? 0 ?></p>
    </div>
    <div class="stat-card">
        <h3>Total Quantity in Stock</h3>
        <p><?= $stock_info['total_quantity'] ?? 0 ?></p>
    </div>
    <div class="stat-card">
        <h3>Pending Prescriptions</h3>
        <p><?= $pending_prescriptions->num_rows ?></p>
    </div>
</div>

<h2>Low Stock Medicines (≤ 10 units)</h2>
<?php if ($low_stock->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Medicine Name</th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($row = $low_stock->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['medicine_name']) ?></td>
            <td><?= htmlspecialchars($row['quantity']) ?></td>
            <td><a href="../modules/pharmacy/edit.php?id=<?= $row['id'] ?>" class="btn">Restock</a></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
    <p>All medicines have sufficient stock.</p>
<?php endif; ?>

<h2>Pending Prescriptions</h2>
<?php if ($pending_prescriptions->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Patient</th>
            <th>Total Amount</th>
            <th>Status</th>
            <th>Date Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($prescription = $pending_prescriptions->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($prescription['patient_name']) ?></td>
            <td>$<?= number_format($prescription['total_amount'], 2) ?></td>
            <td><?= htmlspecialchars(ucfirst($prescription['status'])) ?></td>
            <td><?= htmlspecialchars($prescription['created_at']) ?></td>
            <td>
                <a href="../billing/edit.php?id=<?= $prescription['id'] ?>" class="btn">Process</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
    <p>No pending prescriptions.</p>
<?php endif; ?>

<h2>Quick Links</h2>
<ul class="quick-links">
    <li><a href="../modules/pharmacy/manage.php">Manage Pharmacy Stock</a></li>
    <li><a href="../billing/manage.php">Manage Billing & Prescriptions</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
