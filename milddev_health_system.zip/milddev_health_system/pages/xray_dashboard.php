<?php
require_once 'includes/auth.php';
require_roles(['xray', 'admin']);
require_once 'config/db.php';
include 'includes/header.php';

$sql = $conn->query("
    SELECT a.id, p.full_name, a.appointment_date, a.reason 
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE a.reason LIKE '%x-ray%' OR a.reason LIKE '%radiology%' 
    ORDER BY a.appointment_date DESC
");
?>

<h2>X-Ray Dashboard</h2>

<?php if ($sql->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Date</th>
                <th>Reason</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $sql->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['full_name']) ?></td>
                <td><?= htmlspecialchars($row['appointment_date']) ?></td>
                <td><?= htmlspecialchars($row['reason']) ?></td>
                <td>
                    <a href="appointments/upload_result.php?id=<?= $row['id'] ?>" class="btn">Upload Scan</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No X-ray appointments found.</p>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/xray_dashboard.php
?>
<?php
// End of file: milddev_heath_system/pages/xray_dashboard.php
?>
<?php
// End of file: milddev_heath_system/pages/xray_dashboard.php   
?>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $pending_list->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['full_name']) ?></td>
                <td><?= htmlspecialchars($row['test_type']) ?></td>
                <td><?= htmlspecialchars($row['scheduled_date']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td>
                    <a href="view_test.php?id=<?= $row['id'] ?>" class="btn">View</a>
                    <a href="edit_test.php?id=<?= $row['id'] ?>" class="btn">Edit</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
<p>No pending lab tests found.</p>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system    
?>
<?php
// End of file: milddev_heath_system/pages/labaratorian_dashboard.php
?>  