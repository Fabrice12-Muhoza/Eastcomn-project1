<?php
session_start();
require_once '../../config/db.php';

// Only admin allowed here
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$success = $error = '';

// Handle deletion
if (isset($_GET['delete'])) {
    $del_id = (int) $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $del_id);
    if ($stmt->execute()) {
        $success = "User deleted successfully.";
    } else {
        $error = "Error deleting user.";
    }
}

// Handle add new user form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password']; // **You should hash this in real app**
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role = $_POST['role'];

    if (!$username || !$password || !$full_name || !$role) {
        $error = "Please fill all required fields.";
    } else {
        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username already taken.";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, email, phone, role) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $username, $password, $full_name, $email, $phone, $role);
            if ($stmt->execute()) {
                $success = "User added successfully.";
            } else {
                $error = "Failed to add user.";
            }
        }
    }
}

// Fetch all users
$result = $conn->query("SELECT * FROM users ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>User Management - MHS</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h2 { color: #4CAF50; }
    table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background-color: #eee; }
    .success { color: green; margin-bottom: 15px; }
    .error { color: red; margin-bottom: 15px; }
    form { margin-top: 30px; max-width: 400px; }
    input, select { width: 100%; padding: 8px; margin: 8px 0; box-sizing: border-box; }
    button { background-color: #4CAF50; color: white; padding: 10px; border: none; cursor: pointer; }
    button:hover { background-color: #45a049; }
    a.delete-link { color: red; text-decoration: none; }
    a.delete-link:hover { text-decoration: underline; }
</style>
</head>
<body>

<h2>User Management Panel</h2>

<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($user = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $user['id'] ?></td>
            <td><?= htmlspecialchars($user['username']) ?></td>
            <td><?= htmlspecialchars($user['full_name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= htmlspecialchars($user['phone']) ?></td>
            <td><?= htmlspecialchars($user['role']) ?></td>
            <td>
                <a href="edit.php?id=<?= $user['id'] ?>">Edit</a> |
                <a class="delete-link" href="?delete=<?= $user['id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<h3>Add New User</h3>
<form method="POST" action="">
    <input type="text" name="username" placeholder="Username" required />
    <input type="password" name="password" placeholder="Password" required />
    <input type="text" name="full_name" placeholder="Full Name" required />
    <input type="email" name="email" placeholder="Email (optional)" />
    <input type="text" name="phone" placeholder="Phone (optional)" />
    <select name="role" required>
        <option value="">Select Role</option>
        <option value="admin">Admin</option>
        <option value="doctor">Doctor</option>
        <option value="nurse">Nurse</option>
        <option value="receptionist">Receptionist</option>
        <option value="xray">X-ray Staff</option>
        <option value="pharmacist">Pharmacist</option>
        <option value="laboratorian">Laboratorian</option>
    </select>
    <button type="submit" name="add_user">Add User</button>
</form>

<p><a href="../admin_dashboard.php">Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>

</body>
</html>
