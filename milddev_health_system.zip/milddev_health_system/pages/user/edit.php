<?php
session_start();
require_once '../../config/db.php';

// Only admin allowed here
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$error = $success = '';
$user_id = $_GET['id'] ?? null;

if (!$user_id) {
    header('Location: manage.php');
    exit;
}

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header('Location: manage.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    if (!$username || !$full_name || !$role) {
        $error = "Please fill all required fields.";
    } else {
        // Check if username is taken by another user
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt_check->bind_param("si", $username, $user_id);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $error = "Username already taken by another user.";
        } else {
            if ($password) {
                // Update including password
                // NOTE: Hash password in real system
                $stmt_update = $conn->prepare("UPDATE users SET username = ?, password = ?, full_name = ?, email = ?, phone = ?, role = ? WHERE id = ?");
                $stmt_update->bind_param("ssssssi", $username, $password, $full_name, $email, $phone, $role, $user_id);
            } else {
                // Update without changing password
                $stmt_update = $conn->prepare("UPDATE users SET username = ?, full_name = ?, email = ?, phone = ?, role = ? WHERE id = ?");
                $stmt_update->bind_param("sssssi", $username, $full_name, $email, $phone, $role, $user_id);
            }

            if ($stmt_update->execute()) {
                $success = "User updated successfully.";
                // Refresh user data
                $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
            } else {
                $error = "Failed to update user.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Edit User - MHS</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    h2 { color: #4CAF50; }
    form { max-width: 400px; }
    input, select { width: 100%; padding: 8px; margin: 8px 0; box-sizing: border-box; }
    button { background-color: #4CAF50; color: white; padding: 10px; border: none; cursor: pointer; }
    button:hover { background-color: #45a049; }
    .success { color: green; margin-bottom: 15px; }
    .error { color: red; margin-bottom: 15px; }
</style>
</head>
<body>

<h2>Edit User</h2>

<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="">
    <label>Username *</label>
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required />

    <label>Password (leave blank to keep current)</label>
    <input type="password" name="password" placeholder="New password" />

    <label>Full Name *</label>
    <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required />

    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" />

    <label>Phone</label>
    <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" />

    <label>Role *</label>
    <select name="role" required>
        <option value="">Select Role</option>
        <?php
        $roles = ['admin', 'doctor', 'nurse', 'receptionist', 'xray', 'pharmacist', 'laboratorian'];
        foreach ($roles as $r) {
            $selected = ($user['role'] === $r) ? 'selected' : '';
            echo "<option value=\"$r\" $selected>" . ucfirst($r) . "</option>";
        }
        ?>
    </select>

    <button type="submit">Update User</button>
</form>

<p><a href="manage.php">Back to User Management</a></p>

</body>
</html>
