<?php
require_once '../includes/auth.php';
require_roles(['receptionist']);
require_once '../config/db.php';
include '../includes/header.php';

// Count total patients
$sql_patients = $conn->query("SELECT COUNT(*) AS total FROM patients");
$total_patients = $sql_patients->fetch_assoc()['total'];

// Count today's appointments
$sql_today_appointments = $conn->query("
    SELECT COUNT(*) AS total 
    FROM appointments 
    WHERE DATE(appointment_date) = CURDATE()
");
$today_appointments = $sql_today_appointments->fetch_assoc()['total'];

// Get upcoming appointments
$sql_upcoming = $conn->query("
    SELECT a.id, p.full_name, a.appointment_date, a.status 
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    WHERE a.appointment_date >= CURDATE() 
    ORDER BY a.appointment_date ASC 
    LIMIT 5
");
?>

<h1>Receptionist Dashboard</h1>

<div class="dashboard-stats">
    <div class="stat-card">
        <h3>Total Patients</h3>
        <p><?= $total_patients ?></p>
    </div>
    <div class="stat-card">
        <h3>Today's Appointments</h3>
        <p><?= $today_appointments ?></p>
    </div>
</div>

<h2>Upcoming Appointments</h2>
<?php if ($sql_upcoming->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Patient Name</th>
                <th>Appointment Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $sql_upcoming->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= htmlspecialchars($row['appointment_date']) ?></td>
                    <td><?= ucfirst($row['status']) ?></td>
                    <td>
                        <a href="../appointments/edit.php?id=<?= $row['id'] ?>" class="btn">Edit</a>
                        <a href="../appointments/delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No upcoming appointments.</p>
<?php endif; ?>

<h2>Quick Links</h2>
<ul class="quick-links">
    <li><a href="../appointments/manage.php">Manage Appointments</a></li>
    <li><a href="../modules/patients/manage.php">Manage Patients</a></li>
    <li><a href="../appointments/add.php">Add New Appointment</a></li>
</ul>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/pages/receptionist_dashboard.php
?>
<?php
// End of file: milddev_heath_system/pages/receptionist_dashboard.php
?>
<li><a href="../appointments/calendar.php">View Calendar</a></li>
<?php
