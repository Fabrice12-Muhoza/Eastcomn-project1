    </main>

    <footer style="text-align:center; padding: 15px; background-color:#f1f1f1; color:#555; margin-top: 40px;">
        <p>&copy; <?= date('Y') ?> Mild Dev Health System (MHS) | Developed by Fabrice MUHOZA</p>
    </footer>

    <!-- Optional JavaScript -->
    <script src="../js/script.js"></script>

    <!-- Chart.js (only load if used) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</body>
</html>
