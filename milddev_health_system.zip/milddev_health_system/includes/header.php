<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mild Dev Health System (MHS)</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <!-- Favicon (optional) -->
    <link rel="icon" type="image/png" href="../assets/favicon.png">
</head>
<body>

    <!-- Header / Title -->
    <header>
        🏥 Mild Dev Health System (MHS)
    </header>

    <!-- Main Content Area -->
    <main class="container">
