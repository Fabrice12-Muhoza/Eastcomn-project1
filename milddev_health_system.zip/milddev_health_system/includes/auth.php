<?php
session_start();

/**
 * Redirect to login page if user is not logged in.
 */
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../pages/login.php'); // Adjust path if needed
        exit;
    }
}

/**
 * Require specific user roles to access a page.
 * Usage: require_roles(['admin', 'doctor']);
 * @param array $allowed_roles
 */
function require_roles(array $allowed_roles) {
    require_login();

    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
        // Optional: customize forbidden message or redirect
        header('HTTP/1.1 403 Forbidden');
        echo "<h1>Access Denied</h1>";
        echo "<p>You do not have permission to access this page.</p>";
        exit;
    }
}

/**
 * Log out the current user and destroy session.
 */
function logout() {
    session_start();
    session_unset();
    session_destroy();
    header('Location: ../pages/login.php'); // Redirect to login after logout
    exit;
}
