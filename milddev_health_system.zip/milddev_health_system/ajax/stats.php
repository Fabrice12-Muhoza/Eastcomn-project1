<?php
// Load DB connection
require_once '../config/db.php';

// Get stats for the dashboard
$response = [
  'patients' => 0,
  'appointments' => 0,
  'invoices' => 0,
  'medicines' => 0
];

try {
  $response['patients'] = $conn->query("SELECT COUNT(*) FROM patients")->fetch_row()[0];
  $response['appointments'] = $conn->query("SELECT COUNT(*) FROM appointments")->fetch_row()[0];
  $response['invoices'] = $conn->query("SELECT COUNT(*) FROM billing")->fetch_row()[0];
  $response['medicines'] = $conn->query("SELECT COUNT(*) FROM pharmacy_stock")->fetch_row()[0];
} catch (Exception $e) {
  $response['error'] = "Failed to load stats: " . $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($response);
