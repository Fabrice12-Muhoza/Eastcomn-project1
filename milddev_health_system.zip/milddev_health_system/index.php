<?php
header("Location: pages/login.php");
exit;
// End of file: milddev_heath_system/index.php
?>