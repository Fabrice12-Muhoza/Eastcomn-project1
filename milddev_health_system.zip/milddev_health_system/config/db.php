<?php
$host = 'localhost';        // your database server
$dbname = 'mhs_db';         // your database name
$username = 'root';         // your MySQL username
$password = '';             // your MySQL password (default is blank for XAMPP)

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Optional: set charset
$conn->set_charset("utf8");
?>
