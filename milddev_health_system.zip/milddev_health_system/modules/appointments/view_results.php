<?php
require_once '../includes/auth.php';
require_roles(['doctor', 'admin']);
require_once '../config/db.php';
include '../includes/header.php';

$appointment_id = (int)($_GET['id'] ?? 0);
if (!$appointment_id) {
    echo "<p>Invalid appointment ID.</p>";
    include '../includes/footer.php';
    exit;
}

$stmt = $conn->prepare("
    SELECT xr.*, a.appointment_date, p.full_name 
    FROM xray_results xr
    JOIN appointments a ON xr.appointment_id = a.id
    JOIN patients p ON a.patient_id = p.id
    WHERE xr.appointment_id = ?
");
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();
$result_data = $result->fetch_assoc();

if (!$result_data) {
    echo "<p>No X-ray result found for this appointment.</p>";
    include '../includes/footer.php';
    exit;
}

// Mark related notifications as read
$current_user = $_SESSION['user']['username'];
$conn->query("UPDATE notifications SET is_read = 1 WHERE username = '$current_user' AND message LIKE '%appointment ID #$appointment_id%'");
?>

<h2>X-ray Result for <?= htmlspecialchars($result_data['full_name']) ?></h2>

<p><strong>Date:</strong> <?= htmlspecialchars($result_data['appointment_date']) ?></p>
<p><strong>Uploaded By:</strong> <?= htmlspecialchars($result_data['uploaded_by']) ?></p>
<p><strong>Note:</strong> <?= nl2br(htmlspecialchars($result_data['note'])) ?></p>
<p><strong>Uploaded At:</strong> <?= $result_data['uploaded_at'] ?></p>

<?php
$file = $result_data['file_path'];
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
    echo "<img src='../uploads/xrays/$file' alt='X-ray Image' style='max-width:100%; border:1px solid #ccc;'>";
} elseif ($ext === 'pdf') {
    echo "<embed src='../uploads/xrays/$file' type='application/pdf' width='100%' height='600px' />";
} else {
    echo "<a href='../uploads/xrays/$file' target='_blank'>Download File</a>";
}
?>

<a href="../pages/doctor_dashboard.php" class="btn">← Back to Dashboard</a>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/modules/appointments/view_results.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/view_results.php  
?>
