<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'receptionist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$success = $error = "";

// Fetch all patients from DB
$patients = $conn->query("SELECT id, full_name FROM patients");

// On form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $reason = trim($_POST['reason']);
    $status = $_POST['status'];

    if (!$patient_id || !$appointment_date || !$appointment_time || !$reason) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO appointments (patient_id, appointment_date, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $patient_id, $appointment_date, $appointment_time, $reason, $status);

        if ($stmt->execute()) {
            $success = "Appointment scheduled successfully.";
        } else {
            $error = "Error scheduling appointment: " . $conn->error;
        }
    }
}
?>

<h2>Schedule New Appointment</h2>

<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>

<a href="manage.php" class="btn">← Back to Appointments</a>

<form method="POST">
    <label for="patient_id">Patient</label>
    <select name="patient_id" id="patient_id" required>
        <option value="">-- Select Patient --</option>
        <?php while ($p = $patients->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['full_name']) ?></option>
        <?php endwhile; ?>
    </select>

    <label for="appointment_date">Date</label>
    <input type="date" name="appointment_date" id="appointment_date" required>

    <label for="appointment_time">Time</label>
    <input type="time" name="appointment_time" id="appointment_time" required>

    <label for="reason">Reason for Visit</label>
    <textarea name="reason" id="reason" required></textarea>

    <label for="status">Status</label>
    <select name="status" id="status" required>
        <option value="Scheduled">Scheduled</option>
        <option value="Pending">Pending</option>
        <option value="Completed">Completed</option>
    </select>

    <button type="submit">Add Appointment</button>
</form>

<?php include '../../includes/footer.php'; ?>
