<?php
require_once '../includes/auth.php';
require_roles(['xray', 'admin']);
require_once '../config/db.php';
include '../includes/header.php';

$appointment_id = (int)($_GET['id'] ?? 0);
if (!$appointment_id) {
    echo "<p>Invalid appointment ID.</p>";
    include '../includes/footer.php';
    exit;
}

// Get appointment + patient info
$stmt = $conn->prepare("
    SELECT a.id, a.appointment_date, a.reason, p.full_name 
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    WHERE a.id = ?
");
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();
$appt = $result->fetch_assoc();

if (!$appt) {
    echo "<p>Appointment not found.</p>";
    include '../includes/footer.php';
    exit;
}

$success = $error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $note = trim($_POST['note'] ?? '');
    $file = $_FILES['scan'];

    if ($file['error'] === UPLOAD_ERR_OK && $note) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'pdf'];

        if (in_array($ext, $allowed)) {
            $new_name = 'xray_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
            $target_path = '../uploads/xrays/' . $new_name;

            if (!file_exists('../uploads/xrays')) {
                mkdir('../uploads/xrays', 0777, true);
            }

            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                // Save result
                $stmt = $conn->prepare("INSERT INTO xray_results (appointment_id, file_path, note, uploaded_by) VALUES (?, ?, ?, ?)");
                $uploader = $_SESSION['user']['username'];
                $stmt->bind_param("isss", $appointment_id, $new_name, $note, $uploader);
                if ($stmt->execute()) {
                    if ($stmt->execute()) {

                        $success = "X-ray result uploaded successfully!";

                            // Notify doctor (if assigned)
                        $appt_id = $appointment_id;
                        $doctor_sql = $conn->prepare("SELECT doctor_username FROM appointments WHERE id = ?");
                        $doctor_sql->bind_param("i", $appt_id);
                        $doctor_sql->execute();
                        $doc_result = $doctor_sql->get_result();
                        $doc = $doc_result->fetch_assoc();

                        if ($doc && $doc['doctor_username']) {
                            $doctor_username = $doc['doctor_username'];
                            $notif_msg = "New X-ray result uploaded for appointment ID #$appt_id.";

                            $notify = $conn->prepare("INSERT INTO notifications (username, message) VALUES (?, ?)");
                            $notify->bind_param("ss", $doctor_username, $notif_msg);
                            $notify->execute();
                        }

                    } 
                }
                else {
                    $error = "Failed to save record.";
                }
            } else {
                $error = "Failed to upload file.";
            }
        } else {
            $error = "Invalid file type.";
        }
    } else {
        $error = "All fields required.";
    }
}
?>

<h2>Upload X-ray Result for <?= htmlspecialchars($appt['full_name']) ?></h2>

<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <label>Scan File (jpg, png, pdf) *</label>
    <input type="file" name="scan" accept=".jpg,.jpeg,.png,.pdf" required>

    <label>Note / Observations *</label>
    <textarea name="note" rows="4" required></textarea>

    <button type="submit">Upload Result</button>
</form>

<a href="../xray_dashboard.php" class="btn">← Back</a>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/modules/appointments/upload_results.php
?>  