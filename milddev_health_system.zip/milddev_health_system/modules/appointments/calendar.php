<?php
require_once '../includes/auth.php';
require_roles(['receptionist', 'admin', 'doctor']);
require_once '../config/db.php';
include '../includes/header.php';

// Fetch appointment events as JSON-compatible array
$appointments = [];
$sql = $conn->query("
    SELECT a.id, a.appointment_date, a.status, p.full_name
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
");

while ($row = $sql->fetch_assoc()) {
    $appointments[] = [
        'title' => $row['full_name'] . ' (' . ucfirst($row['status']) . ')',
        'start' => $row['appointment_date'],
        'url'   => 'edit.php?id=' . $row['id']
    ];
}
?>

<h2>Appointments Calendar</h2>

<link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.js'></script>

<div id='calendar'></div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      initialView: 'dayGridMonth',
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,listWeek'
      },
      events: <?= json_encode($appointments) ?>,
      eventClick: function(info) {
        // Open in new tab
        window.open(info.event.url, '_blank');
        info.jsEvent.preventDefault();
      }
    });

    calendar.render();
  });
</script>

<style>
  #calendar {
    max-width: 1000px;
    margin: 40px auto;
  }
</style>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/modules/appointments/calendar.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/calendar.php
?>  