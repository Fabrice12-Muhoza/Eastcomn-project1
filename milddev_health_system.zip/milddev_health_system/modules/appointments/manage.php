<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'receptionist']);
require_once '../../config/db.php';
include '../../includes/header.php';

// Fetch all appointments with patient names
$sql = "SELECT a.*, p.full_name AS patient_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        ORDER BY a.appointment_date DESC, a.appointment_time DESC";

$result = $conn->query($sql);
?>

<h2>Appointments</h2>

<a href="add.php" class="btn">➕ Add Appointment</a>

<?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Date</th>
                <th>Time</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['patient_name']) ?></td>
                <td><?= htmlspecialchars($row['appointment_date']) ?></td>
                <td><?= htmlspecialchars($row['appointment_time']) ?></td>
                <td><?= htmlspecialchars($row['reason']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                    <a href="delete.php?id=<?= $row['id'] ?>" class="btn" onclick="return confirm('Are you sure you want to delete this appointment?')">🗑️ Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No appointments found.</p>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
<a href="print_slip.php?id=<?= $row['id'] ?>" target="_blank" class="btn">Print Slip</a>
<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>

<a href="manage.php" class="btn">← Back to Appointments</a>

<?php
// End of file: milddev_heath_system/modules/appointments/manage.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/manage.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/manage.php
