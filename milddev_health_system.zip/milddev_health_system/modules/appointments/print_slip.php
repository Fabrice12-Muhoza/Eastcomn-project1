<?php
require_once '../includes/auth.php';
require_roles(['receptionist', 'admin']);
require_once '../config/db.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    echo "<p>Invalid appointment ID.</p>";
    exit;
}

// Fetch appointment & patient details
$stmt = $conn->prepare("
    SELECT a.*, p.full_name, p.phone
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    WHERE a.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$appointment = $result->fetch_assoc();

if (!$appointment) {
    echo "<p>Appointment not found.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointment Slip</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
            max-width: 600px;
            margin: auto;
            border: 1px solid #ccc;
        }
        h2 { text-align: center; }
        .field {
            margin: 12px 0;
        }
        .label {
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            font-size: 0.9em;
            color: #888;
        }
        .print-btn {
            margin: 20px 0;
            display: block;
            text-align: center;
        }
    </style>
</head>
<body onload="window.print()">

    <h2>Mild Dev Health System</h2>
    <h3>Appointment Slip</h3>

    <div class="field"><span class="label">Patient:</span> <?= htmlspecialchars($appointment['full_name']) ?></div>
    <div class="field"><span class="label">Phone:</span> <?= htmlspecialchars($appointment['phone']) ?></div>
    <div class="field"><span class="label">Appointment ID:</span> <?= $appointment['id'] ?></div>
    <div class="field"><span class="label">Date & Time:</span> <?= date("d M Y, h:i A", strtotime($appointment['appointment_date'])) ?></div>
    <div class="field"><span class="label">Reason:</span> <?= htmlspecialchars($appointment['reason']) ?></div>
    <div class="field"><span class="label">Status:</span> <?= ucfirst($appointment['status']) ?></div>

    <div class="footer">Printed on <?= date("d M Y, h:i A") ?> | Receptionist Panel</div>

</body>
</html>
<?php
// End of file: milddev_heath_system/modules/appointments/print_slip.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/print_slip.php    