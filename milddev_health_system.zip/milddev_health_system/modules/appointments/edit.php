<?php
require_once '../includes/auth.php';
require_roles(['receptionist', 'admin']);
require_once '../config/db.php';
include '../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    echo "<p>Invalid appointment ID.</p>";
    include '../includes/footer.php';
    exit;
}

$stmt = $conn->prepare("SELECT * FROM appointments WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$appointment = $result->fetch_assoc();

if (!$appointment) {
    echo "<p>Appointment not found.</p>";
    include '../includes/footer.php';
    exit;
}

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $appointment_date = $_POST['appointment_date'];
    $reason = trim($_POST['reason']);
    $status = $_POST['status'];

    if ($appointment_date && $status) {
        $stmt = $conn->prepare("UPDATE appointments SET appointment_date = ?, reason = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sssi", $appointment_date, $reason, $status, $id);
        if ($stmt->execute()) {
            $success = "Appointment updated successfully.";
            $appointment = $_POST;
        } else {
            $error = "Update failed.";
        }
    } else {
        $error = "Date and status are required.";
    }
}
?>

<h2>Edit Appointment</h2>

<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>

<form method="POST">
    <label>Appointment Date *</label>
    <input type="datetime-local" name="appointment_date" value="<?= htmlspecialchars($appointment['appointment_date']) ?>" required>

    <label>Reason</label>
    <input type="text" name="reason" value="<?= htmlspecialchars($appointment['reason']) ?>">

    <label>Status *</label>
    <select name="status" required>
        <option value="pending" <?= $appointment['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="approved" <?= $appointment['status'] === 'approved' ? 'selected' : '' ?>>Approved</option>
        <option value="completed" <?= $appointment['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
        <option value="cancelled" <?= $appointment['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
    </select>

    <button type="submit">Update Appointment</button>
</form>

<a href="manage.php" class="btn">← Back</a>

<?php include '../includes/footer.php'; ?>
<?php
// End of file: milddev_heath_system/modules/appointments/edit.php
?>
<?php
// End of file: milddev_heath_system/modules/appointments/edit.php