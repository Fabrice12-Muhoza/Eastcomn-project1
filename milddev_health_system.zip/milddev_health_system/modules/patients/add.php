<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'receptionist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$error = $success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $contact = trim($_POST['contact']);
    $address = trim($_POST['address']);
    $email = trim($_POST['email']);

    if (!$full_name || !$dob || !$gender || !$contact || !$address) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && $email !== '') {
        $error = "Invalid email format.";
    } else {
        // Insert patient data
        $stmt = $conn->prepare("INSERT INTO patients (full_name, dob, gender, contact, address, email) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $full_name, $dob, $gender, $contact, $address, $email);

        if ($stmt->execute()) {
            $success = "Patient added successfully.";
        } else {
            $error = "Error adding patient: " . $conn->error;
        }
    }
}
?>

<h2>Add New Patient</h2>

<?php if ($error): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success"><?= $success ?></div>
<?php endif; ?>

<a href="manage.php" class="btn">← Back to Patients</a>

<form method="POST" autocomplete="off">
    <label for="full_name">Full Name <span style="color:red;">*</span></label>
    <input type="text" name="full_name" id="full_name" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">

    <label for="dob">Date of Birth <span style="color:red;">*</span></label>
    <input type="date" name="dob" id="dob" required value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>">

    <label for="gender">Gender <span style="color:red;">*</span></label>
    <select name="gender" id="gender" required>
        <option value="">-- Select Gender --</option>
        <option value="Male" <?= (($_POST['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
        <option value="Female" <?= (($_POST['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
        <option value="Other" <?= (($_POST['gender'] ?? '') === 'Other') ? 'selected' : '' ?>>Other</option>
    </select>

    <label for="contact">Contact Number <span style="color:red;">*</span></label>
    <input type="text" name="contact" id="contact" required value="<?= htmlspecialchars($_POST['contact'] ?? '') ?>">

    <label for="address">Address <span style="color:red;">*</span></label>
    <textarea name="address" id="address" required><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>

    <label for="email">Email (Optional)</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

    <button type="submit">Add Patient</button>
</form>

<?php include '../../includes/footer.php'; ?>
<?php
// Include footer
include '../../includes/footer.php';
?>
<?php
// End of file: milddev_heath_system/modules/patients/add.php
?>  