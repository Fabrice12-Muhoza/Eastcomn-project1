<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'receptionist']);
require_once '../../config/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: manage.php");
    exit;
}

// Optionally: Check if patient is linked to appointments or billing before deleting

$stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: manage.php?msg=deleted");
} else {
    header("Location: manage.php?error=delete_failed");
}
exit;
?>
<?php
// End of file: milddev_heath_system/modules/patients/delete.php
?>
<?php
// End of file: milddev_heath_system/modules/patients/delete.php