<?php
require_once '../../includes/auth.php';
require_roles(['receptionist', 'admin']);
require_once '../../config/db.php';
include '../../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    echo "<p>Invalid patient ID.</p>";
    include '../../includes/footer.php';
    exit;
}

$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$patient = $result->fetch_assoc();

if (!$patient) {
    echo "<p>Patient not found.</p>";
    include '../../includes/footer.php';
    exit;
}

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);

    if ($full_name && $dob && $gender && $phone) {
        $stmt = $conn->prepare("UPDATE patients SET full_name = ?, date_of_birth = ?, gender = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $full_name, $dob, $gender, $phone, $id);
        if ($stmt->execute()) {
            $success = "Patient updated successfully.";
            $patient = $_POST;
        } else {
            $error = "Update failed.";
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<h2>Edit Patient Info</h2>

<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>
<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>

<form method="POST">
    <label>Full Name *</label>
    <input type="text" name="full_name" value="<?= htmlspecialchars($patient['full_name']) ?>" required>

    <label>Date of Birth *</label>
    <input type="date" name="dob" value="<?= htmlspecialchars($patient['date_of_birth']) ?>" required>

    <label>Gender *</label>
    <select name="gender" required>
        <option value="Male" <?= $patient['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
        <option value="Female" <?= $patient['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
    </select>

    <label>Phone *</label>
    <input type="text" name="phone" value="<?= htmlspecialchars($patient['phone']) ?>" required>

    <button type="submit">Update</button>
</form>

<a href="manage.php" class="btn">← Back</a>

<?php include '../../includes/footer.php'; ?>
