<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'receptionist']);
require_once '../../config/db.php';
include '../../includes/header.php';

// Fetch all patients
$sql = "SELECT * FROM patients ORDER BY full_name ASC";
$result = $conn->query($sql);
?>

<h2>Patients</h2>

<a href="add.php" class="btn">➕ Add Patient</a>

<?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Full Name</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['full_name']) ?></td>
                <td><?= htmlspecialchars($row['dob']) ?></td>
                <td><?= htmlspecialchars($row['gender']) ?></td>
                <td><?= htmlspecialchars($row['contact']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['address']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                    <a href="delete.php?id=<?= $row['id'] ?>" class="btn" onclick="return confirm('Are you sure you want to delete this patient?')">🗑️ Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No patients found.</p>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
<?php