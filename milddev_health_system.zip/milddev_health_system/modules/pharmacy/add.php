<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$error = $success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_name = trim($_POST['medicine_name']);
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $expiry_date = $_POST['expiry_date'];

    if (!$medicine_name || !$quantity || !$price || !$expiry_date) {
        $error = "All fields are required.";
    } elseif (!is_numeric($quantity) || $quantity <= 0) {
        $error = "Quantity must be a positive number.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "Price must be a positive number.";
    } else {
        $stmt = $conn->prepare("INSERT INTO pharmacy_stock (medicine_name, quantity, price, expiry_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sids", $medicine_name, $quantity, $price, $expiry_date);

        if ($stmt->execute()) {
            $success = "Medicine added to stock successfully.";
        } else {
            $error = "Error adding medicine: " . $conn->error;
        }
    }
}
?>

<h2>Add Medicine to Pharmacy Stock</h2>

<?php if ($error): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success"><?= $success ?></div>
<?php endif; ?>

<a href="manage.php" class="btn">← Back to Pharmacy Stock</a>

<form method="POST" autocomplete="off">
    <label for="medicine_name">Medicine Name <span style="color:red;">*</span></label>
    <input type="text" name="medicine_name" id="medicine_name" required value="<?= htmlspecialchars($_POST['medicine_name'] ?? '') ?>">

    <label for="quantity">Quantity <span style="color:red;">*</span></label>
    <input type="number" name="quantity" id="quantity" min="1" required value="<?= htmlspecialchars($_POST['quantity'] ?? '') ?>">

    <label for="price">Price per unit ($) <span style="color:red;">*</span></label>
    <input type="number" name="price" id="price" min="0.01" step="0.01" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">

    <label for="expiry_date">Expiry Date <span style="color:red;">*</span></label>
    <input type="date" name="expiry_date" id="expiry_date" required value="<?= htmlspecialchars($_POST['expiry_date'] ?? '') ?>">

    <button type="submit">Add Medicine</button>
</form>

<?php include '../../includes/footer.php'; ?>
<?php