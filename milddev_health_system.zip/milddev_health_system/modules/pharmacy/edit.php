<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$id = $_GET['id'] ?? null;
$error = $success = "";

if (!$id) {
    echo "<p class='error'>Invalid request. No medicine ID specified.</p>";
    include '../../includes/footer.php';
    exit;
}

// Fetch existing medicine
$stmt = $conn->prepare("SELECT * FROM pharmacy_stock WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$medicine = $stmt->get_result()->fetch_assoc();

if (!$medicine) {
    echo "<p class='error'>Medicine not found.</p>";
    include '../../includes/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_name = trim($_POST['medicine_name']);
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $expiry_date = $_POST['expiry_date'];

    if (!$medicine_name || !$quantity || !$price || !$expiry_date) {
        $error = "All fields are required.";
    } elseif (!is_numeric($quantity) || $quantity <= 0) {
        $error = "Quantity must be a positive number.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "Price must be a positive number.";
    } else {
        $stmt = $conn->prepare("UPDATE pharmacy_stock SET medicine_name=?, quantity=?, price=?, expiry_date=? WHERE id=?");
        $stmt->bind_param("sidsi", $medicine_name, $quantity, $price, $expiry_date, $id);

        if ($stmt->execute()) {
            $success = "Medicine updated successfully.";
            // Refresh medicine data
            $medicine['medicine_name'] = $medicine_name;
            $medicine['quantity'] = $quantity;
            $medicine['price'] = $price;
            $medicine['expiry_date'] = $expiry_date;
        } else {
            $error = "Error updating medicine: " . $conn->error;
        }
    }
}
?>

<h2>Edit Medicine</h2>

<?php if ($error): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success"><?= $success ?></div>
<?php endif; ?>

<a href="manage.php" class="btn">← Back to Pharmacy Stock</a>

<form method="POST" autocomplete="off">
    <label for="medicine_name">Medicine Name <span style="color:red;">*</span></label>
    <input type="text" name="medicine_name" id="medicine_name" required value="<?= htmlspecialchars($medicine['medicine_name']) ?>">

    <label for="quantity">Quantity <span style="color:red;">*</span></label>
    <input type="number" name="quantity" id="quantity" min="1" required value="<?= htmlspecialchars($medicine['quantity']) ?>">

    <label for="price">Price per unit ($) <span style="color:red;">*</span></label>
    <input type="number" name="price" id="price" min="0.01" step="0.01" required value="<?= htmlspecialchars($medicine['price']) ?>">

    <label for="expiry_date">Expiry Date <span style="color:red;">*</span></label>
    <input type="date" name="expiry_date" id="expiry_date" required value="<?= htmlspecialchars($medicine['expiry_date']) ?>">

    <button type="submit">Update Medicine</button>
</form>

<?php include '../../includes/footer.php'; ?>
<?php