<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

// Fetch all pharmacy stock items
$sql = "SELECT * FROM pharmacy_stock ORDER BY expiry_date ASC";
$result = $conn->query($sql);
?>

<h2>Pharmacy Stock Management</h2>

<a href="add.php" class="btn">➕ Add New Medicine</a>

<?php if ($result->num_rows > 0): ?>
<table>
    <thead>
        <tr>
            <th>Medicine Name</th>
            <th>Quantity</th>
            <th>Price per unit ($)</th>
            <th>Expiry Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['medicine_name']) ?></td>
            <td><?= $row['quantity'] ?></td>
            <td><?= number_format($row['price'], 2) ?></td>
            <td><?= htmlspecialchars($row['expiry_date']) ?></td>
            <td>
                <a href="edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                <a href="delete.php?id=<?= $row['id'] ?>" class="btn" onclick="return confirm('Are you sure you want to delete this medicine?')">🗑️ Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
<p>No medicines in stock.</p>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
<?php