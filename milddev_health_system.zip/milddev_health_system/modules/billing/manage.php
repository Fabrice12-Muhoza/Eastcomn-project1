<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

// Fetch billing with patient names
$sql = "SELECT b.*, p.full_name AS patient_name 
        FROM billing b 
        JOIN patients p ON b.patient_id = p.id 
        ORDER BY b.billing_date DESC";

$result = $conn->query($sql);
?>

<h2>Billing Records</h2>

<a href="add.php" class="btn">➕ Add Billing</a>

<?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Invoice #</th>
                <th>Patient</th>
                <th>Date</th>
                <th>Description</th>
                <th>Amount ($)</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['patient_name']) ?></td>
                <td><?= htmlspecialchars($row['billing_date']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= number_format($row['amount'], 2) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn">✏️ Edit</a>
                    <a href="delete.php?id=<?= $row['id'] ?>" class="btn" onclick="return confirm('Delete this billing record?')">🗑️ Delete</a>
                    <a href="billing_pdf.php?id=<?= $row['id'] ?>" class="btn" target="_blank">📄 PDF</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No billing records found.</p>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>

<a href="manage.php" class="btn">← Back to Billing</a>

<form method="POST">
    <label for="patient_id">Patient</label>
    <select name="patient_id" id="patient_id" required>
        <option value="">-- Select Patient --</option>
        <?php while ($p = $patients->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>" <?= $billing['patient_id'] == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['full_name']) ?></option>
        <?php endwhile; ?>
    </select>

    <label for="billing_date">Billing Date</label>
    <input type="date" name="billing_date" id="billing_date" required value="<?= htmlspecialchars($billing['billing_date']) ?>">

    <label for="amount">Amount ($)</label>
    <input type="number" name="amount" id="amount" min="0.01" step="0.01" required value="<?= htmlspecialchars($billing['amount']) ?>">

    <label for="description">Description</label>
    <textarea name="description" id="description" required><?= htmlspecialchars($billing['description']) ?></textarea>  
    <label for="status">Status</label>
    <select name="status" id="status" required>
        <option value="Unpaid" <?= $billing['status'] == 'Unpaid' ? 'selected' : '' ?>>Unpaid</option>
        <option value="Paid" <?= $billing['status'] == 'Paid' ? 'selected' : '' ?>>Paid</option>
        <option value="Pending" <?= $billing['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
    </select>

    <button type="submit">Update Billing</button>
</form>

<?php include '../../includes/footer.php'; ?>   
<?php
require_once '../includes/auth.php';
require_roles(['pharmacist', 'admin']);
require_once '../config/db.php';
include '../includes/header.php';

// Fetch all billing records, latest first
$sql = "
    SELECT b.id, p.full_name AS patient_name, b.total_amount, b.status, b.created_at
    FROM billing b
    JOIN patients p ON b.patient_id = p.id
    ORDER BY b.created_at DESC
";

$result = $conn->query($sql);
?>

<h2>Manage Billing & Prescriptions</h2>
<table>
    <thead>
        <tr>
            <th>Patient</th>
            <th>Total Amount</th>
            <th>Status</th>
            <th>Date Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['patient_name']) ?></td>
                    <td>$<?= number_format($row['total_amount'], 2) ?></td>
                    <td><?= htmlspecialchars(ucfirst($row['status'])) ?></td>
                    <td><?= htmlspecialchars($row['created_at']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn">Edit</a>
                        <?php if ($row['status'] !== 'dispensed'): ?>
                            <a href="process.php?id=<?= $row['id'] ?>" onclick="return confirm('Mark this prescription as dispensed?');" class="btn btn-success">Mark Dispensed</a>
                        <?php endif; ?>
                        <a href="billing_pdf.php?id=<?= $row['id'] ?>" target="_blank" class="btn">Print Invoice</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5">No billing records found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include '../includes/footer.php'; ?>
<td>' . htmlspecialchars($billing['status']) . '</td>
    </tr>
</table>';

// Output HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Add footer
$pdf->Ln(10);
$pdf->Cell(0, 10, 'Thank you for your business!', 0, 1, 'C');

// Close and output PDF document
$pdf->Output('invoice_' . $billing['id'] . '.pdf', 'I');
exit;
<?php
// End of file: milddev_heath_system/modules/billing/manage.php
?>  