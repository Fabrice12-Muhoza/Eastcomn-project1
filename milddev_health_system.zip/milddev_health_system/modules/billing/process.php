<?php
require_once '../includes/auth.php';
require_roles(['pharmacist', 'admin']);
require_once '../config/db.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: manage.php');
    exit;
}

// Update status to 'dispensed'
$stmt = $conn->prepare("UPDATE billing SET status = 'dispensed' WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header('Location: manage.php');
exit;
?>
<?php
// End of file: milddev_heath_system/modules/billing/process.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Process Billing</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container">
    <h2>Billing Processed</h2>
    <p>The billing record has been successfully processed.</p>
    <a href="manage.php" class="btn">Back to Billing Management</a>
</div>
</body>
</html>
<?php
// End of file: milddev_heath_system/modules/billing/process.php
?>
<?php
// End of file: milddev_heath_system/modules/billing/process.php    