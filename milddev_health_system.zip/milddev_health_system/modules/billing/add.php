<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$error = $success = "";

// Fetch patients to link billing
$patients = $conn->query("SELECT id, full_name FROM patients");

// On form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $amount = $_POST['amount'];
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $billing_date = $_POST['billing_date'];

    if (!$patient_id || !$amount || !$description || !$billing_date) {
        $error = "All fields are required.";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number.";
    } else {
        $stmt = $conn->prepare("INSERT INTO billing (patient_id, amount, description, status, billing_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("idsss", $patient_id, $amount, $description, $status, $billing_date);

        if ($stmt->execute()) {
            $success = "Billing record added successfully.";
        } else {
            $error = "Error adding billing: " . $conn->error;
        }
    }
}
?>

<h2>Add Billing Record</h2>

<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>

<a href="manage.php" class="btn">← Back to Billing</a>

<form method="POST">
    <label for="patient_id">Patient</label>
    <select name="patient_id" id="patient_id" required>
        <option value="">-- Select Patient --</option>
        <?php while ($p = $patients->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['full_name']) ?></option>
        <?php endwhile; ?>
    </select>

    <label for="billing_date">Billing Date</label>
    <input type="date" name="billing_date" id="billing_date" required value="<?= date('Y-m-d') ?>">

    <label for="amount">Amount ($)</label>
    <input type="number" name="amount" id="amount" min="0.01" step="0.01" required>

    <label for="description">Description</label>
    <textarea name="description" id="description" required></textarea>

    <label for="status">Status</label>
    <select name="status" id="status" required>
        <option value="Unpaid">Unpaid</option>
        <option value="Paid">Paid</option>
        <option value="Pending">Pending</option>
    </select>

    <button type="submit">Add Billing</button>
</form>

<?php include '../../includes/footer.php'; ?>
