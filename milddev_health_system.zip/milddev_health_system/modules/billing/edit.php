<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'pharmacist']);
require_once '../../config/db.php';
include '../../includes/header.php';

$id = $_GET['id'] ?? null;
$error = $success = "";

if (!$id) {
    echo "<p class='error'>Invalid request. No billing ID specified.</p>";
    include '../../includes/footer.php';
    exit;
}

// Fetch billing record
$stmt = $conn->prepare("SELECT * FROM billing WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$billing = $stmt->get_result()->fetch_assoc();

if (!$billing) {
    echo "<p class='error'>Billing record not found.</p>";
    include '../../includes/footer.php';
    exit;
}

// Fetch patients
$patients = $conn->query("SELECT id, full_name FROM patients");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $amount = $_POST['amount'];
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $billing_date = $_POST['billing_date'];

    if (!$patient_id || !$amount || !$description || !$billing_date) {
        $error = "All fields are required.";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number.";
    } else {
        $stmt = $conn->prepare("UPDATE billing SET patient_id=?, amount=?, description=?, status=?, billing_date=? WHERE id=?");
        $stmt->bind_param("idsssi", $patient_id, $amount, $description, $status, $billing_date, $id);

        if ($stmt->execute()) {
            $success = "Billing record updated successfully.";
            // Refresh data
            $billing['patient_id'] = $patient_id;
            $billing['amount'] = $amount;
            $billing['description'] = $description;
            $billing['status'] = $status;
            $billing['billing_date'] = $billing_date;
        } else {
            $error = "Error updating billing: " . $conn->error;
        }
    }
}
?>

<h2>Edit Billing Record</h2>

<?php if ($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
<?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>

<a href="manage.php" class="btn">← Back to Billing</a>

<form method="POST">
    <label for="patient_id">Patient</label>
    <select name="patient_id" id="patient_id" required>
        <option value="">-- Select Patient --</option>
        <?php while ($p = $patients->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>" <?= $billing['patient_id'] == $p['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['full_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label for="billing_date">Billing Date</label>
    <input type="date" name="billing_date" id="billing_date" required value="<?= $billing['billing_date'] ?>">

    <label for="amount">Amount ($)</label>
    <input type="number" name="amount" id="amount" min="0.01" step="0.01" required value="<?= $billing['amount'] ?>">

    <label for="description">Description</label>
    <textarea name="description" id="description" required><?= htmlspecialchars($billing['description']) ?></textarea>

    <label for="status">Status</label>
    <select name="status" id="status" required>
        <option value="Unpaid" <?= $billing['status'] == 'Unpaid' ? 'selected' : '' ?>>Unpaid</option>
        <option value="Paid" <?= $billing['status'] == 'Paid' ? 'selected' : '' ?>>Paid</option>
        <option value="Pending" <?= $billing['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
    </select>

    <button type="submit">Update Billing</button>
</form>

<?php include '../../includes/footer.php'; ?>
