<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'pharmacist']);
require_once '../../config/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: manage.php");
    exit;
}

$stmt = $conn->prepare("DELETE FROM billing WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: manage.php?msg=deleted");
} else {
    header("Location: manage.php?error=delete_failed");
}
exit;
