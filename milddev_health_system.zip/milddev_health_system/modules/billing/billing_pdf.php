<?php
require_once '../../includes/auth.php';
require_roles(['admin', 'doctor', 'pharmacist']);
require_once '../../config/db.php';

// Include TCPDF library
require_once '../../tcpdf/tcpdf.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    die("No billing ID specified.");
}

// Fetch billing and patient info
$stmt = $conn->prepare("
    SELECT b.*, p.full_name, p.contact
    FROM billing b
    JOIN patients p ON b.patient_id = p.id
    WHERE b.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$billing = $stmt->get_result()->fetch_assoc();

if (!$billing) {
    die("Billing record not found.");
}

// Create new PDF document
$pdf = new TCPDF();
$pdf->SetCreator('MHS');
$pdf->SetAuthor('Mild Dev Health System');
$pdf->SetTitle('Invoice #' . $billing['id']);
$pdf->SetMargins(15, 20, 15);
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Invoice Title
$pdf->Cell(0, 10, 'Invoice #' . $billing['id'], 0, 1, 'C');
$pdf->Ln(5);

// Patient info
$pdf->Cell(0, 6, 'Patient Name: ' . $billing['full_name'], 0, 1);
$pdf->Cell(0, 6, 'Contact: ' . $billing['contact'], 0, 1);
$pdf->Cell(0, 6, 'Billing Date: ' . $billing['billing_date'], 0, 1);
$pdf->Ln(10);

// Billing Details Table
$html = '
<table border="1" cellpadding="5">
    <tr style="background-color:#f0f0f0;">
        <th>Description</th>
        <th>Amount ($)</th>
        <th>Status</th>
    </tr>
    <tr>
        <td>' . htmlspecialchars($billing['description']) . '</td>
        <td>' . number_format($billing['amount'], 2) . '</td>
        <td>' . htmlspecialchars($billing['status']) . '</td>
    </tr>
</table>';

$pdf->writeHTML($html, true, false, false, false, '');

// Footer / Signature
$pdf->Ln(20);
$pdf->Cell(0, 6, 'Thank you for choosing Mild Dev Health System!', 0, 1, 'C');

// Output PDF
$pdf->Output('invoice_' . $billing['id'] . '.pdf', 'I');
