<?php
require_once 'config/db.php';
echo "Database connection successful!";
?>
